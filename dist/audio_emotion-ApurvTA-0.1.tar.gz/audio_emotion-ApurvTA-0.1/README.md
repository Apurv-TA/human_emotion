# Human audio emotion prediction
The purpose of this project is to create an audio emotion detection model which can classify the emotion of the user on the basis of the audio.
s

## Steps performed


## To excute the script with default inputs
python __main__.py

## You can also used add arguments which can be observed by using
python __main__.py -h

## The result of which is given below
python __main__.py [-h] [--log-level LOG_LEVEL] [--log-path LOG_PATH] [--no-console-log] [--data DATA] [--save SAVE] [-v {1,2,3}]
